﻿namespace Spis_Leków.Models
{
    public class Ilosc_lekow
    {
        public int Id { get; set; }
        public int Lek_id { get; set; }
        public int Uzytkownik_id { get; set; }
        public int Ilosc { get; set; }

    }
}
